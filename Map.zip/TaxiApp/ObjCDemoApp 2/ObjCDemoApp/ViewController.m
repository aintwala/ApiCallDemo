/* Copyright (c) 2016 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


#import "ViewController.h"
#import <GoogleMaps/GoogleMaps.h>

@interface ViewController ()<GMSMapViewDelegate>

@end

@implementation ViewController {
  GMSMapView *_mapView;
    BOOL _firstLocationUpdate;
}


- (void)viewDidLoad {
  [super viewDidLoad];
    
    // to fetch current location
    GMSCameraPosition *camera = [GMSCameraPosition cameraWithLatitude:-33.868 longitude:151.2086 zoom:10];
    _mapView = [GMSMapView mapWithFrame:CGRectZero camera:camera];
    _mapView.settings.compassButton = YES;
    _mapView.settings.myLocationButton = YES;
    [_mapView addObserver:self
               forKeyPath:@"myLocation"
                  options:NSKeyValueObservingOptionNew
                  context:NULL];
    self.view = _mapView;
    dispatch_async(dispatch_get_main_queue(), ^{
        _mapView.myLocationEnabled = YES;
    });
    
    // pin two different location
    GMSMarker *marker = [[GMSMarker alloc] init];
    marker.position = CLLocationCoordinate2DMake(-33.868, 151.2086);
    marker.title = @"Sydney";
    marker.snippet = @"Australia";
    marker.map = _mapView;
    [_mapView setSelectedMarker:marker];
    
    GMSMarker *marker1 = [[GMSMarker alloc] init];
    marker1.position = CLLocationCoordinate2DMake(-32.92, 151.78);
    marker1.title = @"Newcastle";
    marker1.snippet = @"Australia";
    marker1.map = _mapView;
    [_mapView setSelectedMarker:marker1];
    
    [self routeBetweenTwoLocation];
}

- (void)dealloc {
    [_mapView removeObserver:self
                  forKeyPath:@"myLocation"
                     context:NULL];
}

- (void)observeValueForKeyPath:(NSString *)keyPath
                      ofObject:(id)object
                        change:(NSDictionary *)change
                       context:(void *)context {
    if (!_firstLocationUpdate) {
        // If the first location update has not yet been recieved, then jump to that location.
         _firstLocationUpdate = YES;
        CLLocation *location = [change objectForKey:NSKeyValueChangeNewKey];
        _mapView.camera = [GMSCameraPosition cameraWithTarget:location.coordinate zoom:14];
    }
}

#pragma mark drawRoute

- (void)routeBetweenTwoLocation {
    //dispatch_async(dispatch_get_main_queue(), ^{
        CLLocation *myOrigin = [[CLLocation alloc] initWithLatitude:-33.868 longitude: 151.2086];
        CLLocation *myDestination = [[CLLocation alloc] initWithLatitude:-32.92 longitude:151.78];
        [self fetchPolylineWithOrigin:myOrigin destination:myDestination completionHandler:^(GMSPolyline *polyline) {
             if(polyline)
                 polyline.map = _mapView;
         }];
   // });
    }
    
- (void)fetchPolylineWithOrigin:(CLLocation *)origin destination:(CLLocation *)destination completionHandler:(void (^)(GMSPolyline *))completionHandler {
        NSString *originString = [NSString stringWithFormat:@"%f,%f", origin.coordinate.latitude, origin.coordinate.longitude];
        NSString *destinationString = [NSString stringWithFormat:@"%f,%f", destination.coordinate.latitude, destination.coordinate.longitude];
        NSString *directionsAPI = @"https://maps.googleapis.com/maps/api/directions/json?";
        NSString *directionsUrlString = [NSString stringWithFormat:@"%@&origin=%@&destination=%@&mode=driving", directionsAPI, originString, destinationString];
        NSURL *directionsUrl = [NSURL URLWithString:directionsUrlString];
        NSURLSessionDataTask *fetchDirectionsTask = [[NSURLSession sharedSession] dataTaskWithURL:directionsUrl completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error) {
            NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
            if(error) {
                if(completionHandler) completionHandler(nil);
                return;
            }
            NSArray *routesArray = [json objectForKey:@"routes"];
             __block GMSPolyline *polyline = nil;
            if ([routesArray count] > 0) {
                    NSDictionary *routeDict = [routesArray objectAtIndex:0];
                    NSDictionary *routeOverviewPolyline = [routeDict objectForKey:@"overview_polyline"];
                    NSString *points = [routeOverviewPolyline objectForKey:@"points"];
                     __block GMSPath *path = [GMSPath pathFromEncodedPath:points];
                dispatch_sync(dispatch_get_main_queue(), ^{
                    polyline = [GMSPolyline polylineWithPath:path];
                    if(completionHandler)completionHandler(polyline);
                });
            }
        }];        // run completionHandler on main thread
        [fetchDirectionsTask resume];
    }

@end

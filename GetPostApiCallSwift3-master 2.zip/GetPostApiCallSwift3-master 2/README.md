# GetPostApiCallSwift3
get &amp; post method using ApiCall Class 
